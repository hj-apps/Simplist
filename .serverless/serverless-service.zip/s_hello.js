var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
orgId: 'hjapps',
applicationName: 'simplist',
appUid: '7XVW7c7VkCCQ69H7m3',
orgUid: 'G0yrJHWQspFDV2xXks',
deploymentUid: 'b108bbcf-a51c-4cba-b1e7-a31ede618af4',
serviceName: 'serverless-service',
shouldLogMeta: true,
stageName: 'dev',
pluginVersion: '3.4.1'})
const handlerWrapperArgs = { functionName: 'serverless-service-dev-hello', timeout: 6}
try {
  const userHandler = require('./handler.js')
  module.exports.handler = serverlessSDK.handler(userHandler.hello, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
